/**
 * Wall.java
 * Paint the walls. It has three different ways to paint the walls
 * horizontal, vertical, square.
 */
package poyingyu_2515_ass02v1;

import java.awt.*;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class Wall extends JPanel {

    public static final int WALL_SIZE = 20;
    private ImageIcon wallImage;
    private int wall_x, wall_y;
    private int wall_length;
    private int VH;
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1;
    public static final int SQUARE=2;

    public Wall() {
        this.wall_length = 0;
        this.wall_x = 0;
        this.wall_y = 0;

    }

    /**
     * 
     * @param length the length of walls
     * @param x
     * @param y
     * @param d the direction of walls
     */
    public Wall(int length, int x, int y, int d) {
        this.wall_length = length;
        this.wall_x = x;
        this.wall_y = y;
        this.VH = d;
    }
    public int getWallX()
    {
        return wall_x;
    }
    public int getWallY()
    {
        return wall_y;
    }
    public void paintWall(Graphics page) {
        int temp_x = wall_x;
        int temp_y = wall_y;
        super.paintComponent(page);
        wallImage = new ImageIcon("images/wall_3.png");
        if (VH == HORIZONTAL) {
            for (int i = 0; i < wall_length / WALL_SIZE; i++) {

                wallImage.paintIcon(this, page, temp_x, temp_y);
                //Block the area. Don't let player pass though the wall
                ComponentInteraction.setBlockWall(temp_x, temp_y);
                temp_x += WALL_SIZE;
            }
            
        }
        else if(VH ==VERTICAL )
        {
            for (int i = 0; i < wall_length / WALL_SIZE; i++) {

                wallImage.paintIcon(this, page, temp_x, temp_y);
                 //Block the area. Don't let player pass though the wall
                ComponentInteraction.setBlockWall(temp_x, temp_y);
                temp_y += WALL_SIZE;
            }
            
        }
        else if(VH==SQUARE)
        {
            for(int j=0;j<wall_length/WALL_SIZE;j++)
            {
                for (int i = 0; i < wall_length / WALL_SIZE; i++) {

                 wallImage.paintIcon(this, page, temp_x, temp_y); 
                  //Block the area. Don't let player pass though the wall
                 ComponentInteraction.setBlockWall(temp_x, temp_y);
                temp_x += WALL_SIZE;
                }
               temp_x = wall_x;
                temp_y-=WALL_SIZE;
            }
              
        }
        
    }

}
