package poyingyu_2515_ass02v1;

/**
 * DirectionPanel.java
 * The controller Panel.
 * Declare the components and connect each classes.
 * Do the action and control the direction of player
 */
/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.border.LineBorder;

/**
 *
 * @author Zach Yu A00932303
 */
public class DirectionPanel extends JPanel {

   
    public static final int WIDTH = 500, HEIGHT = 500;//the size of DirectionPanel
    private final int MOVE_UNIT = 5;  // increment for image movement
    private final int RUN_SPEED = 2; //the speed of player run
    private final int JUMP_HIGH = 20;//the high when player jump
    private final int IMAGE_SURFACE_DIVIDE_QUANTUM = 5; // Divide image to pieces
    public static final int IMAGE_SIZE_H = 50; //image hieght
    public static final int IMAGE_SIZE_W = 31; // image width
    protected static int image_x, image_y; // the position of image
    private ImageIcon up, down, right, left, currentImage, sitL, sitR;//set up images
    private Color wallColor = Color.DARK_GRAY; // wall Color
    private char direction = 'r'; // the direction of image now
    private int steps = 0; // count the steps to switch two images
    private int moveX = 0;
    private int moveY = 3;//move Y pixel each timer period.
    public static Timer timer;
    private int gameTime = 0;//calculate the game time.
    public static ArrayList<Wall> wall = new ArrayList<Wall>(); //the static components of stages
    public static ArrayList<Wall> wall2 = new ArrayList<Wall>();
    public static ArrayList<Wall> wall3 = new ArrayList<Wall>();
    public static ArrayList<Wall> wall4 = new ArrayList<Wall>();
    public static ArrayList<Fire> fire = new ArrayList<Fire>();
    public static ArrayList<Fire> fire2 = new ArrayList<Fire>();
    public static ArrayList<Fire> fire3 = new ArrayList<Fire>();
    public static Gate gate = new Gate();
    public static Gate gate2 = new Gate();
    public static Gate gate3 = new Gate();
    public static Door door = new Door();
    public static Door door2 = new Door();
    public static Door door3 = new Door();
    public static Key key = new Key();
    public static Key key2 = new Key();
    public static Key key3 = new Key();
    protected final int DELAY = 25; //delay time of timer
    private int stageNum = 1; //the stage Number decide which stage would go
    public static boolean doorOpen = false; 
    public static int deathCount = 0;//count death time   
    private BuildStage stage = new BuildStage();
     private JLabel deathTimesLabel=new JLabel();
     private JLabel gameTimeLabel=new JLabel();
     private int minutes,seconds; // time convert to minustes and seconds
    //-----------------------------------------------------------------
    //  Constructor: Sets up this panel and loads the images.
    //-----------------------------------------------------------------
    public DirectionPanel() {
        addKeyListener(new DirectionListener());
        timer = new Timer(DELAY, new ReboundListener());

        //initialize original point of image
        image_x = 10;
        image_y = 100;

        up = new ImageIcon("images/presidentRs.png");
        down = new ImageIcon("images/presidentRs.png");
        sitL = new ImageIcon("images/president2Ls.png"); //second move when it run
        sitR = new ImageIcon("images/president2Rs.png"); //second move when it run
        left = new ImageIcon("images/presidentLs.png"); //regular left side image
        right = new ImageIcon("images/presidentRs.png"); // regular right side image 
        currentImage = right; //initialize the current Image.
        //set up panel
       
        stage.setStage(stageNum);
        
        setBackground(Color.LIGHT_GRAY);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        timer.start();

    }
    //-----------------------------------------------------------------
    //  Draws the image in the current location.
    //-----------------------------------------------------------------

    public void paintComponent(Graphics page) {
        super.paintComponent(page);
        //Pick a stage
        switch (stageNum) {
            case 1:
                gate.paintGate(page);
                key.paintKey(page);
                door.paintDoor(page);
                for (int i = 0; i < fire.size(); i++) {
                    fire.get(i).paintFire(page);
                }
                for (int i = 0; i < wall.size(); i++) {
                    wall.get(i).paintWall(page);
                }
                break;
            case 2:
                gate2.paintGate(page);
                key2.paintKey(page);
                door2.paintDoor(page);
                for (int i = 0; i < fire2.size(); i++) {
                    fire2.get(i).paintFire(page);
                }
                for (int i = 0; i < wall2.size(); i++) {
                    wall2.get(i).paintWall(page);
                }
                break;
            case 3:
                gate3.paintGate(page);
                key3.paintKey(page);
                door3.paintDoor(page);
                for (int i = 0; i < fire3.size(); i++) {
                    fire3.get(i).paintFire(page);
                }
                for (int i = 0; i < wall3.size(); i++) {
                    wall3.get(i).paintWall(page);
                }
            break;
              
            default:
                for(int i=0;i<wall4.size();i++)
                {
                    wall4.get(i).paintWall(page);
                }
               
                break;
        }
        currentImage.paintIcon(this, page, image_x, image_y);

        //paint the enter hole
        page.setColor(Color.BLACK);
        page.fillOval(0, 0, 50, 10);
        page.fillOval(550, 290, 50, 10);

    }
    //*****************************************************************
    //  Represents the listener for keyboard activity.
    //*****************************************************************

    private class DirectionListener implements KeyListener {
        //----------------------------------------------
        // Responds to the user pressing arrow keys by adjusting the
// image and image location accordingly.
//--------------------------------------------------------------

        public void keyPressed(KeyEvent event) {
            //Save the position
            int tempX = image_x;
            int tempY = image_y;

            switch (event.getKeyCode()) {

                case KeyEvent.VK_DOWN:
                    //check the direction of last move to decide the image direction
                    if (direction == 'r') {
                        currentImage = right;
                    } else {
                        currentImage = left;
                    }

                    image_y += MOVE_UNIT;
                    //check the image pass though hole, when user press down
                    if (metWall() == true) {
                        image_x = tempX;
                        image_y = tempY;
                    }

                    //reset the steps
                    if (steps >= 2) {
                        steps = 0;
                    }
                    break;
                case KeyEvent.VK_LEFT:
                    //switch two images
                    steps++;
                    if (steps % 2 == 0) {
                        currentImage = left;
                    } else {
                        currentImage = sitL;
                    }
                    //Speed up function
                    for (int i = 0; i < RUN_SPEED; i++) {
                        image_x -= MOVE_UNIT;
                        //set up the direciton
                        direction = 'l';
                        if (metWall() == true) {
                            image_x = tempX;
                            image_y = tempY;
                        }
                    }
                    //reset the steps
                    if (steps >= 2) {
                        steps = 0;
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    steps++;
                    //switch two images 
                    if (steps % 2 == 0) {
                        currentImage = right;
                    } else {
                        currentImage = sitR;
                    }
                    //Speed up function
                    for (int i = 0; i < RUN_SPEED; i++) {
                        image_x += MOVE_UNIT;
                        //set up the direciton
                        direction = 'r';
                        if (metWall() == true) {
                            image_x = tempX;
                            image_y = tempY;
                        }
                    }
                    //reset the steps
                    if (steps >= 2) {
                        steps = 0;
                    }
                    break;
                case KeyEvent.VK_UP:

                    if (onTheGround() == true) {
                        //Jump High controler, would not touch the wall of top
                        for (int i = 0; i < JUMP_HIGH; i++) {

                            if (direction == 'r') {
                                currentImage = right;
                            } else {
                                currentImage = left;
                            }

                            image_y -= MOVE_UNIT;

                            if (metWall() == true) {

                                if (image_y <= ComponentInteraction.block_y) {

                                    image_x = image_x;
                                    image_y = image_y + (ComponentInteraction.block_y - image_y);
                                    break;
                                }
                            }
                        }

                    }
                    break;
                case KeyEvent.VK_SPACE:
                    //the image can jump when it only stand on the ground 
                    if (onTheGround() == true) {
                           //Jump High controler, would not touch the wall of top
                        for (int i = 0; i < JUMP_HIGH; i++) {

                            if (direction == 'r') {
                                currentImage = right;
                            } else {
                                currentImage = left;
                            }

                            image_y -= MOVE_UNIT;

                            if (metWall() == true) {

                                if (image_y <= ComponentInteraction.block_y) {

                                    image_x = image_x;
                                    image_y = image_y + (ComponentInteraction.block_y - image_y);
                                    break;
                                }
                            }
                        }

                    }
                    break;
            }
            // If the image touch the wall, make it back to last move.
            if (stageNum == 1) {
                doorOpen = ComponentInteraction.getKey(image_x + IMAGE_SIZE_W, image_y + IMAGE_SIZE_H);
            } else if (stageNum == 2) {
                doorOpen = ComponentInteraction.getKey(image_x + IMAGE_SIZE_W, image_y + IMAGE_SIZE_H);
            } else if (stageNum == 3) {
               doorOpen = ComponentInteraction.getKey(image_x + IMAGE_SIZE_W, image_y + IMAGE_SIZE_H);
            }

            repaint();

        }
//--------------------------------------------------------------
        // Provide empty definitions for unused event methods.
        //--------------------------------------------------------------

        public void keyTyped(KeyEvent event) {

        }

        public void keyReleased(KeyEvent event) {

        }

    }

  

    /**
     * metWall() Check the image touch the wall or not. If the image touch the
     * wall, return true. If the image didn't touch wall return false.
     *
     * @return boolean
     */
    public boolean metWall() {
        //set up the image bottom left right top
        int image_bottom = image_y + IMAGE_SIZE_H;
        int image_left = image_x;
        int image_right = image_x + IMAGE_SIZE_W;
        int image_top = image_y;

        if (ComponentInteraction.pass(image_x, image_y) == false) {

            return true;
        } else {
            //divide the image to make sure the body would not pass the wall
            for (int i = 1; i < IMAGE_SURFACE_DIVIDE_QUANTUM; i++) {
                if (ComponentInteraction.pass(image_x + IMAGE_SIZE_W * i / (IMAGE_SURFACE_DIVIDE_QUANTUM - 1), image_y) == false) {

                    return true;
                } else if (ComponentInteraction.pass(image_x, image_y + IMAGE_SIZE_H * i / (IMAGE_SURFACE_DIVIDE_QUANTUM - 1)) == false) {

                    return true;
                } else if (ComponentInteraction.pass(image_x + IMAGE_SIZE_W, image_y + IMAGE_SIZE_H * i / (IMAGE_SURFACE_DIVIDE_QUANTUM - 1)) == false) {

                    return true;
                } else if (ComponentInteraction.pass(image_x + IMAGE_SIZE_W * i / (IMAGE_SURFACE_DIVIDE_QUANTUM - 1), image_y + IMAGE_SIZE_H) == false) {

                    return true;
                } else if (image_bottom > 500 || image_right > 500 || image_top < 0 || image_left < 0) {
                    return true;
                }
            }
            return false;
        }

    }
    //Check the image is on the ground or not
    public boolean onTheGround() {
        int tempY = image_y;

        if (image_y + IMAGE_SIZE_H + 5 > HEIGHT) {
            return true;
        }
        for (int i = 1; i < IMAGE_SURFACE_DIVIDE_QUANTUM; i++) {
            if (ComponentInteraction.pass(image_x + IMAGE_SIZE_W * i / (IMAGE_SURFACE_DIVIDE_QUANTUM - 1), image_y + IMAGE_SIZE_H + MOVE_UNIT) == false) {
                return true;
            }
        }
        return false;

    }

    /**
     * Timer listener
     */
    private class ReboundListener implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            int tempY = image_y;
            image_y += moveY;
            //convert time to minutes and seconds
            gameTime++;
            double gameTimeD = gameTime / 40;
            minutes = (int) gameTimeD / 60;
            seconds = (int) gameTimeD % 60;
            InformationPanel.setLabelDeathText("Death: " + Integer.toString(deathCount));
            InformationPanel.setLabelGameTimeText("Time: " + Integer.toString(minutes) + ":" + Integer.toString(seconds));
            InformationPanel.setLabelLevelText("Level: " + Integer.toString(stageNum));
            //uncomplete yet for final stage.
            if(stageNum==4)
        {
             deathTimesLabel = new JLabel("Death Times: "+Integer.toString(deathCount));
             deathTimesLabel.setFont(new Font("Georgia",Font.BOLD,20));   
             deathTimesLabel.setBorder(new LineBorder(Color.black,5,true));
             gameTimeLabel =new JLabel("Game Time:"+Integer.toString(minutes)+":"+Integer.toString(seconds));
             gameTimeLabel.setFont(new Font("Georgia",Font.BOLD,20));
             gameTimeLabel.setBorder(new LineBorder(Color.black,5,true));
                add(deathTimesLabel);
                add(gameTimeLabel);
                
        }
             deathTimesLabel.setText("Death Times: "+Integer.toString(deathCount));
            gameTimeLabel.setText("Game Time:"+Integer.toString(minutes)+":"+Integer.toString(seconds));
            //make sure the image on the ground
            if (metWall() == true) {

                image_y = tempY;
            }
            //go to next stage
            if (ComponentInteraction.passDoor(image_x, image_y) == true) {
               
                ComponentInteraction.reset();
                stageNum++;
                stage.setStage(stageNum);
                image_x = 10;
                image_y = 100;

            }
            //the player dead and go back the begin position, deathCount increase.
            if (ComponentInteraction.touchFire(image_x, image_y + IMAGE_SIZE_H) == true) {

                ComponentInteraction.reset();
                deathCount++;
                stage.setStage(stageNum);
                image_x = 10;
                image_y = 100;
            }
            repaint();
        }
    }
    //reset function
    public void reset() {
        gameTime = 0;
        doorOpen = false;
        stageNum=1;
        deathCount=0;
        ComponentInteraction.reset();

    }

}

//*
