/**
 * Fire.java
 * Paint the Fire
 */
package poyingyu_2515_ass02v1;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import static poyingyu_2515_ass02v1.Wall.WALL_SIZE;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class Fire extends JPanel{
     public static final int FIRE_SIZE=40;
     
     private  ImageIcon fireImage;
     private  int fire_x, fire_y;
     private  int fireLength;
     public static boolean touched=false;
     public Fire()
     {
         this.fire_x=0;
         this.fire_y=0;
     }
     public Fire(int length,int x,int y)
     {
         this.fireLength=length;
         this.fire_x=x;
         this.fire_y=y;
     }
     public void paintFire(Graphics page) {
        int temp_x = fire_x;
        int temp_y = fire_y;
         fireImage = new ImageIcon("images/Fire7.gif");
        super.paintComponent(page);
        for (int i = 0; i < fireLength / FIRE_SIZE; i++) {

                fireImage.paintIcon(this, page, temp_x, temp_y);   
                //save fire position to Components Interation
                ComponentInteraction.setFirePosition(temp_x,temp_y);
                temp_x += FIRE_SIZE;
            }
       
        
     }
     
   
}
