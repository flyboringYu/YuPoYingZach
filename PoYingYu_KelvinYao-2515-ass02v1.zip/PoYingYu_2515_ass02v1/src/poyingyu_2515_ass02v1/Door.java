/**
 * Door.java
 * Paint door.
 */
package poyingyu_2515_ass02v1;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class Door extends JPanel{
     public static final int Door_W=40;
     public static final int Door_H=100;
     private ImageIcon doorImage;
     private int door_x, door_y;
     
    public Door()
     {
         this.door_x=0;
         this.door_y=0;
     }
     public Door(int x,int y)
     {
         this.door_x=x;
         this.door_y=y;
     }
     public void paintDoor(Graphics page) {
        
        super.paintComponent(page);
        doorImage = new ImageIcon("images/door2.png");
        doorImage.paintIcon(this, page, door_x, door_y);
        //save door place to component Interaction.
        ComponentInteraction.setDoorPosition(door_x, door_y);
     }
    
}
