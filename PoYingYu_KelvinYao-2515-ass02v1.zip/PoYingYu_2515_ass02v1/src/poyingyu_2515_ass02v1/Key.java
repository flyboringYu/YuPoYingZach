/**
 * Key.java
 * Paint the key.
 */
package poyingyu_2515_ass02v1;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class Key extends JPanel{
     public static final int KEY_W=40;
     public static final int KEY_H=20;
     private ImageIcon keyImage;
     private int key_x, key_y;
     public Key()
     {
         this.key_x=0;
         this.key_y=0;
     }
     public Key(int x,int y)
     {
         this.key_x=x;
         this.key_y=y;
     }
     public void paintKey(Graphics page) {
        int temp_x = key_x;
        int temp_y = key_y+1;
        super.paintComponent(page);
        //When the key is getten by player, it would not paint anymore.
        if(ComponentInteraction.gotKey==false)
        {
        keyImage = new ImageIcon("images/key.png");
        keyImage.paintIcon(this, page, key_x, key_y);
        ComponentInteraction.setKeyPosition(key_x,key_y);
        }
        
        
     }
     
   
    
}
