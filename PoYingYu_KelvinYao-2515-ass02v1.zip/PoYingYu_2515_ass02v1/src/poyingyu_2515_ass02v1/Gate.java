/**
 * Gate.java
 * Paint the Gate;
 */
package poyingyu_2515_ass02v1;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import static poyingyu_2515_ass02v1.Wall.WALL_SIZE;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class Gate extends JPanel{
    public static final int GATE_SIZE=20;
     
     private ImageIcon gateImage;
     private int gate_x, gate_y;
     private int gateLength;
     
     public Gate()
     {
         this.gate_x=0;
         this.gate_y=0;
     }
     /**
      * 
      * @param length the length of gates
      * @param x
      * @param y 
      */
     public Gate(int length,int x,int y)
     {
         this.gateLength=length;
         this.gate_x=x;
         this.gate_y=y;
     }
     public void paintGate(Graphics page) {
        int temp_x = gate_x;
        int temp_y = gate_y;
        super.paintComponent(page);
        gateImage = new ImageIcon("images/wall.jpg");
        for (int i = 0; i < gateLength / GATE_SIZE; i++) {
                //Door doesn't open, so keep to paint the gate
                if(DirectionPanel.doorOpen==false)
                {
                gateImage.paintIcon(this, page, temp_x, temp_y);
                 //Block the area. Don't let player pass though the gate
                ComponentInteraction.setBlockGate(temp_x, temp_y);
                temp_y += GATE_SIZE;
                }
                //Door opened, clear blockgate and doesn't paint gate anymore
                else
                {
                    ComponentInteraction.blockGate.clear();
                }
                
            }
     }
}
