/**
 * BuildStage.java
 * This class would set up the positions of static components.Building the stages
 * Choice the stage by the stageNum 
 */
package poyingyu_2515_ass02v1;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class BuildStage {

    private int stageNumber;
    
    public BuildStage()
    {
        stageNumber=1;
    }
    public void setStage(int num) {
       
        stageNumber=num; 
        switch (stageNumber) {
            case 1:
               
                DirectionPanel.fire.add (new Fire(80, 420, 460));
                DirectionPanel.gate= new Gate(100, 100, 400);
                DirectionPanel.key=new Key(380, 240);
                DirectionPanel.door=new Door(0, 400);
                DirectionPanel.wall.add(new Wall(120, 0, 380, 0));
                for (int i = 0; i < 12; i++) {
                    DirectionPanel.wall.add(new Wall(260 - i * Wall.WALL_SIZE, 160 + i * Wall.WALL_SIZE, 480 - i * Wall.WALL_SIZE, 0));
                }
                break;
            case 2:
                DirectionPanel.gate2=new Gate(100,100,300);
                DirectionPanel.door2=new Door(0,300);
                DirectionPanel.key2=new Key(440,340);
                DirectionPanel.fire2.add(new Fire(40,160,460));
                DirectionPanel.fire2.add(new Fire(40,240,460));
                DirectionPanel.fire2.add(new Fire(40,320,460));
                DirectionPanel.wall2.add(new Wall(120, 0, 280, 0));
                DirectionPanel.wall2.add(new Wall(100,400,380,0));
                DirectionPanel.wall2.add(new Wall(60,440,360,0));
                for(int i=0;i<5;i++)
                {
                   
                    DirectionPanel.wall2.add(new Wall(160,0,480-i*Wall.WALL_SIZE,0));
                    DirectionPanel.wall2.add(new Wall(40,200,480-i*Wall.WALL_SIZE,0));
                    DirectionPanel.wall2.add(new Wall(40,280,480-i*Wall.WALL_SIZE,0));
                    DirectionPanel.wall2.add(new Wall(140,360,480-i*Wall.WALL_SIZE,0));
                }
                break;
            case 3:
                DirectionPanel.door3 = new Door(0,300);
                DirectionPanel.key3 = new Key(140,140);
                DirectionPanel.gate3 = new Gate(100,60,300);
                DirectionPanel.fire3.add(new Fire(500, 0,460 ));
                DirectionPanel.wall3.add(new Wall(80, 0, 280, 0));
                DirectionPanel.wall3.add(new Wall(140,0,400,0));
                DirectionPanel.wall3.add(new Wall(80,180,380,0));
                DirectionPanel.wall3.add(new Wall(80,300,400,0));
                DirectionPanel.wall3.add(new Wall(80,420,380,0));
                DirectionPanel.wall3.add(new Wall(40,460,360,2));
                DirectionPanel.wall3.add(new Wall(40,420,260,0));
                
                for(int i=0;i<3;i++)
                {
                    DirectionPanel.wall3.add(new Wall(80,300,260-i*Wall.WALL_SIZE,0));
                    DirectionPanel.wall3.add(new Wall(160,100,200-i*Wall.WALL_SIZE,0));
                }
                for(int i=0;i<7;i++)
                {
                    DirectionPanel.wall3.add(new Wall(40,100,140-i*Wall.WALL_SIZE,2));
                }
                
                
                break;
                 
                 case 5:

                DirectionPanel.wall3.add(new Wall(360, 55, 0, 1));
                //stair1 
                for (int i = 0; i < 4; i++) {
                    DirectionPanel.wall3.add(new Wall(200 - i * Wall.WALL_SIZE, 75 + i * Wall.WALL_SIZE, 480 - i * Wall.WALL_SIZE, 0));
                    //fianl x=115 , y=420
                }
                for (int i = 0; i < 4; i++) {
                    DirectionPanel.wall3.add(new Wall(100 - i * Wall.WALL_SIZE, 335 + i * Wall.WALL_SIZE, 480 - i * Wall.WALL_SIZE, 0));
                }
                //air stage 1 x = 170, y = 340
                DirectionPanel.wall3.add(new Wall(350, 170, 420 - Wall.WALL_SIZE * 4, 0));
                //air stage 2 x=230, y= 260
                DirectionPanel.wall3.add(new Wall(290, 230, 340 - Wall.WALL_SIZE * 4, 0));
                //air stage 3 x=75, y=180 
                DirectionPanel.wall3.add(new Wall(260, 75, 260 - Wall.WALL_SIZE * 4, 0));
                //make cube
                DirectionPanel.wall3.add(new Wall(40, 235, 180, 2));
                DirectionPanel.wall3.add(new Wall(40, 75, 180, 2));
                DirectionPanel.wall3.add(new Wall(40, 115, 180, 2));
                DirectionPanel.wall3.add(new Wall(40, 155, 180, 2));
                DirectionPanel.wall3.add(new Wall(200, 315, 100, 0));
                break;
            default:
                DirectionPanel.wall4.add(new Wall(500,0,300,0));
                break;
        }

    }
    public int getStageNum()
    {
        return stageNumber;
    }
    public void reset()
    {
        DirectionPanel.wall.clear();
        DirectionPanel.wall2.clear();
        DirectionPanel.wall3.clear();
        DirectionPanel.fire.clear();
        DirectionPanel.fire2.clear();
        DirectionPanel.fire3.clear();
        DirectionPanel.gate=new Gate();
        DirectionPanel.gate2=new Gate();
        DirectionPanel.gate3=new Gate();
        DirectionPanel.door=new Door();
        DirectionPanel.door2=new Door();
        DirectionPanel.door3=new Door();
        DirectionPanel.key=new Key();
        DirectionPanel.key2=new Key();
        DirectionPanel.key3=new Key();
        DirectionPanel.doorOpen=false;
        ComponentInteraction.gotKey=false;
        ComponentInteraction.reset();
    }

}
