package poyingyu_2515_ass02v1;

//********************************************************************
//  Direction.java       Author: Lewis/Loftus
//
//  Demonstrates key events.
//********************************************************************


/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class Direction
{
     public static InformationPanel IP=new InformationPanel();
     public static ButtonsPanel BP=new ButtonsPanel();
     public static DirectionPanel DP=new DirectionPanel();
   //-----------------------------------------------------------------
   // Creates and displays the application frame.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
      JFrame frame = new JFrame("Direction");
      JPanel integrativePanel=new JPanel();
      integrativePanel.setLayout(new BorderLayout());
      integrativePanel.setBackground(Color.DARK_GRAY);
      
      
      
      integrativePanel.add(IP,BorderLayout.NORTH);
      //integrativePanel.setFocusable(true);
      integrativePanel.add(BP,BorderLayout.SOUTH);
      integrativePanel.add(DP,BorderLayout.CENTER);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().add(integrativePanel);
      DP.requestFocus();
      frame.pack();
      frame.setVisible(true);
   }
}