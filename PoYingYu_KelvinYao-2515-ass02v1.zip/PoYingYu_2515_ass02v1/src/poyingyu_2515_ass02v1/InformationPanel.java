/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poyingyu_2515_ass02v1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class InformationPanel extends JPanel {

    public static JLabel labelDeath = new JLabel("0",JLabel.CENTER);
    public static JLabel labelGameTime = new JLabel("0:0",JLabel.CENTER);
    public static JLabel labelLevel = new JLabel("1",JLabel.CENTER);
    

    public InformationPanel() {
        int minutes;
        int seconds;
        
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        labelDeath.setFont(new Font("Georgia",Font.BOLD,20));
        labelGameTime.setFont(new Font("Georgia",Font.BOLD,20));
        labelLevel.setFont(new Font("Georgia",Font.BOLD,20));
        add(labelDeath,BorderLayout.WEST);
         add(labelGameTime,BorderLayout.CENTER);
         add(labelLevel,BorderLayout.EAST);
         
         
         setPreferredSize(new Dimension(500, 50));
        
       
    }
    public static void setLabelDeathText(String string)
    {
        labelDeath.setText(string);
    }
     public static void setLabelGameTimeText(String string)
    {
         labelGameTime.setText(string);
    }
      public static void setLabelLevelText(String string)
    {
         labelLevel.setText(string);
    }
    
   


}
