/**
 * ButtonPanel.java
 * Set three buttons in this Panel
 * RESTART: reset the game in the same stage
 * RESET: reset the game to first stage and all data clear
 * END: finish the game
 * 
 */
package poyingyu_2515_ass02v1;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import static poyingyu_2515_ass02v1.DirectionPanel.HEIGHT;
import static poyingyu_2515_ass02v1.DirectionPanel.WIDTH;

/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class ButtonsPanel extends JPanel{
    public static final int ButtonP_WIDTH = 500, ButtonP_HEIGHT = 200;
    private  JButton buttonStart = new JButton("RESTART");
    private    JButton buttonReset = new JButton("RESET");
    private    JButton buttonEnd = new JButton("END");
    public ButtonsPanel()
    {
        setLayout(new BorderLayout());
        setBackground(Color.DARK_GRAY);
        ButtonListener listener = new ButtonListener();
       
        
        add(buttonStart,BorderLayout.WEST);
        add(buttonReset,BorderLayout.CENTER);
        add(buttonEnd,BorderLayout.EAST);
        buttonStart.addActionListener(listener);
        buttonReset.addActionListener(listener);
        buttonEnd.addActionListener(listener);
        setPreferredSize(new Dimension(500, 50));
       // setFocusable(true);
    }
    private class ButtonListener implements ActionListener {
      //--------------------------------------------------------------
        //  Determines which button was pressed and sets the label
        //  text accordingly.
        //--------------------------------------------------------------
        
        /**
         * Change the titleP getBackground Color switch between white and red
         * Change the title foreground Color switch between Pink and Black
         * Change dial background Color switch between RED and WHITE
         * @param event 
         */
        public void actionPerformed(ActionEvent event) {
            if(event.getSource()==buttonStart){
               DirectionPanel.image_x=10;
               DirectionPanel.image_y=100;
               ComponentInteraction.reset();
               repaint();
               Direction.DP.requestFocus();
            }
            else if(event.getSource()==buttonReset){
                Direction.DP.reset();
                Direction.DP.requestFocus();
                
            }
            else if(event.getSource()==buttonEnd)
            {
                System.exit(0);
            }
        }
    }
    
}
