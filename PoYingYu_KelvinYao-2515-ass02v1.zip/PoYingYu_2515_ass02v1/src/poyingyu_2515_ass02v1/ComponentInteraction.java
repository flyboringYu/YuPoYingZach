/**
 * ComponentInteraction.java
 * This class would set the interactive behavior between two Components.
 * pass(): decide the component can pass the area or not
 * touchFire(): When the component touch the fire return true.
 * passDoor(): When the component pass the door return true.
 * getKey():When the component get the key return true.
 * reset():reset the componentInteraction.java
 * 
 */


package poyingyu_2515_ass02v1;

import java.awt.Point;
import java.util.ArrayList;
import javax.swing.JPanel;
import static poyingyu_2515_ass02v1.Fire.FIRE_SIZE;
import static poyingyu_2515_ass02v1.Key.KEY_H;
import static poyingyu_2515_ass02v1.Key.KEY_W;


/**
 * @author ZachYu A00932303 KelvenYao A00960311
 */
public class ComponentInteraction {

    private int r_width = DirectionPanel.WIDTH;
    private int r_height = DirectionPanel.HEIGHT;
    public static ArrayList<Point> blockWall = new ArrayList<Point>();
    public static ArrayList<Point> blockGate = new ArrayList<Point>();
    public static ArrayList<Point> firePosition =new ArrayList<Point>();
    public static  Point doorPosition=new Point();
    public static Point keyPosition = new Point();
    public static int block_x, block_y;
    public static int ground_y;
     public static boolean gotKey=false;

    public static void setBlockWall(int x, int y) {

        blockWall.add(new Point(x, y));
    }

    public static void setBlockGate(int x, int y) {

        blockGate.add(new Point(x, y));
    }
    public static void setFirePosition(int x,int y)
    {
        firePosition.add(new Point(x,y));
    }
    public static void setDoorPosition(int x,int y)
    {
        doorPosition = new Point(x,y);
    }
    public static void setKeyPosition(int x, int y)
    {
        keyPosition = new Point(x,y);
    }
    

    public static boolean pass(int x, int y) {
        for (int i = 0; i < blockWall.size(); i++) {
            if (x > blockWall.get(i).x
             && x < (blockWall.get(i).x + Wall.WALL_SIZE)
             && y > blockWall.get(i).y
             && y < blockWall.get(i).y + Wall.WALL_SIZE) {
                ground_y=blockWall.get(i).y;
                block_y=blockWall.get(i).y+Wall.WALL_SIZE;
                return false;
            }

        }
        if (blockGate.isEmpty() == false) {
            for (int i = 0; i < blockGate.size(); i++) {
                if (x > blockGate.get(i).x
                        && x < (blockGate.get(i).x + Wall.WALL_SIZE)
                        && y > blockGate.get(i).y
                        && y < blockGate.get(i).y + Wall.WALL_SIZE) {
                    
                    return false;
                }

            }
        }
        return true;
    }
    
      public static boolean touchFire(int x,int y)
     {
        
        for (int i = 0; i < firePosition.size() ; i++) {
                if(y>= firePosition.get(i).y+FIRE_SIZE/3 && x>=firePosition.get(i).x && x<= firePosition.get(i).x+FIRE_SIZE)
                    return true;    
            }
        return false;
         
     }
     public static boolean passDoor(int x,int y)
     {
         if(x>=doorPosition.x && x<=doorPosition.x+Door.Door_W 
         && y>=doorPosition.y && y<=doorPosition.y+Door.Door_H)
         {
             return true;
         }
         return false;
     }
       public static boolean getKey(int x,int y)
     {
         if(gotKey==true)
         {
             return true;
         }
         if(x>=keyPosition.x+KEY_W/4 && x<=keyPosition.x+KEY_W&& y>=keyPosition.y &&y<=keyPosition.y+KEY_H)
         {
             gotKey=true;
             return true;
         }
         else
         {    
          return false;
         }
         
     }
     public static void reset()
     {
         blockWall.clear();
         blockGate.clear();
         firePosition.clear();
         keyPosition=new Point();
         doorPosition=new Point();
         gotKey=false;
     }
}
